
export const inventarioZapatos = [
    {
        nombre:"Guayos",
        cantidad:23,
        precio:5000

    },
    {
        nombre:"Chanclas",
        cantidad:20,
        precio:50000

    },
    {
        nombre:"Zapatillas",
        cantidad:25,
        precio:15000

    },
    {
        nombre:"Tennis",
        cantidad:3,
        precio:115000

    }

]