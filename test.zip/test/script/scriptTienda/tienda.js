import {imprimirData} from "./functions.js";
import {inventarioZapatos} from "./dataZapatos.js";
imprimirData(inventarioZapatos);